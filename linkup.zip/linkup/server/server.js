const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;
const SALT_ROUNDS = 10; 

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..'))); // Раздаём файлы из родительской папки

// Путь к файлу с пользователями
const usersFilePath = path.join(__dirname, 'users.json');
const messagesFilePath = path.join(__dirname, 'messages.json');

// Функция для чтения пользователей из файла
function readUsers() {
    if (!fs.existsSync(usersFilePath)) {
        fs.writeFileSync(usersFilePath, JSON.stringify([]));
        return [];
    }
    const data = fs.readFileSync(usersFilePath, 'utf8');
    return JSON.parse(data);
}

// Функция для записи пользователей в файл
function writeUsers(users) {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
}

// Функция для генерации уникального ID
function generateId(users) {
    if (users.length === 0) return 1;
    const maxId = Math.max(...users.map(user => user.ID));
    return maxId + 1;
}

// Функции для работы с сообщениями
function readMessages() {
    if (!fs.existsSync(messagesFilePath)) {
        fs.writeFileSync(messagesFilePath, JSON.stringify([]));
        return [];
    }
    const data = fs.readFileSync(messagesFilePath, 'utf8');
    return JSON.parse(data);
}

function writeMessages(messages) {
    fs.writeFileSync(messagesFilePath, JSON.stringify(messages, null, 2));
}

function generateMessageId(messages) {
    if (messages.length === 0) return 1;
    const maxId = Math.max(...messages.map(m => m.id));
    return maxId + 1;
}

// API: Регистрация
app.post('/api/register', async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Заполните все поля' });
    }
    
    const users = readUsers();
    
    // Проверяем, существует ли пользователь
    const userExists = users.some(user => user.username === username);
    if (userExists) {
        return res.status(400).json({ success: false, message: 'Пользователь уже существует' });
    }
    
    // ХЕШИРУЕМ пароль
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
    
    // Создаём нового пользователя (сохраняем хеш, а не пароль)
    const newUser = {
        username: username,
        password: hashedPassword,  // Сохраняем хеш пароля
        ID: generateId(users)
    };
    
    users.push(newUser);
    writeUsers(users);
    
    console.log(`✅ Новый пользователь: ${username} (ID: ${newUser.ID})`);
    res.json({ success: true, message: 'Регистрация успешна', user: { username, ID: newUser.ID } });
});

// API: Авторизация
app.post('/api/login', async (req, res) => { 
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Заполните все поля' });
    }
    
    const users = readUsers();
    const user = users.find(user => user.username === username);
    
    // Проверяем пароль через bcrypt.compare
    if (user && await bcrypt.compare(password, user.password)) {
        console.log(`🔓 Авторизация: ${username} (ID: ${user.ID})`);
        res.json({ success: true, message: 'Вход выполнен', user: { username, ID: user.ID } });
    } else {
        res.status(401).json({ success: false, message: 'Неверный логин или пароль' });
    }
});

// API: Получить всех пользователей (для отладки)
app.get('/api/users', (req, res) => {
    const users = readUsers();
    const safeUsers = users.map(({ password, ...user }) => user);
    res.json(safeUsers);
});

// API: Поиск пользователей по имени
app.get('/api/users/search', (req, res) => {
    const { query } = req.query;
    const currentUsername = req.headers['x-current-user'];
    
    if (!query || query.trim() === '') {
        return res.json([]);
    }
    
    const users = readUsers();
    
    // Ищем пользователей, чье имя содержит поисковый запрос
    const results = users
        .filter(user => 
            user.username.toLowerCase().includes(query.toLowerCase()) &&
            user.username !== currentUsername
        )
        .map(({ username, ID }) => ({ username, ID }));
    
    res.json(results);
});

// API: Получить список чатов для пользователя
app.get('/api/chats/:userId', (req, res) => {
    const { userId } = req.params;
    const messages = readMessages();
    
    // Находим всех собеседников, с которыми были сообщения
    const chatPartners = new Set();
    
    messages.forEach(msg => {
        if (msg.fromId == userId) {
            chatPartners.add(msg.toId);
        } else if (msg.toId == userId) {
            chatPartners.add(msg.fromId);
        }
    });
    
    const users = readUsers();
    const chats = Array.from(chatPartners).map(partnerId => {
        const user = users.find(u => u.ID == partnerId);
        if (!user) return null;
        
        // Получаем последнее сообщение
        const userMessages = messages.filter(m => 
            (m.fromId == userId && m.toId == partnerId) ||
            (m.fromId == partnerId && m.toId == userId)
        );
        
        const lastMessage = userMessages.sort((a,b) => b.timestamp - a.timestamp)[0];
        
        return {
            userId: partnerId,
            username: user.username,
            lastMessage: lastMessage ? lastMessage.text : '',
            lastMessageTime: lastMessage ? lastMessage.timestamp : null
        };
    }).filter(chat => chat !== null);
    
    res.json(chats);
});

// API: Получить сообщения между двумя пользователями
app.get('/api/messages/:userId1/:userId2', (req, res) => {
    const { userId1, userId2 } = req.params;
    const messages = readMessages();
    
    const chatMessages = messages.filter(m => 
        (m.fromId == userId1 && m.toId == userId2) ||
        (m.fromId == userId2 && m.toId == userId1)
    ).sort((a,b) => a.timestamp - b.timestamp);
    
    res.json(chatMessages);
});

// API: Отправить сообщение
app.post('/api/messages', (req, res) => {
    const { fromId, toId, text } = req.body;
    
    if (!fromId || !toId || !text) {
        return res.status(400).json({ success: false, message: 'Недостаточно данных' });
    }
    
    const messages = readMessages();
    
    const newMessage = {
        id: generateMessageId(messages),
        fromId: parseInt(fromId),
        toId: parseInt(toId),
        text: text,
        timestamp: Date.now(),
        read: false
    };
    
    messages.push(newMessage);
    writeMessages(messages);
    
    console.log(`💬 Сообщение: ${newMessage.fromId} -> ${newMessage.toId}: ${text.substring(0, 30)}`);
    res.json({ success: true, message: newMessage });
});

// API: Удалить сообщение (только для отправителя)
app.delete('/api/messages/:messageId/:userId', (req, res) => {
    const { messageId, userId } = req.params;
    let messages = readMessages();
    
    const messageIndex = messages.findIndex(m => m.id == messageId);
    
    if (messageIndex === -1) {
        return res.status(404).json({ success: false, message: 'Сообщение не найдено' });
    }
    
    if (messages[messageIndex].fromId != userId) {
        return res.status(403).json({ success: false, message: 'Можно удалять только свои сообщения' });
    }
    
    messages.splice(messageIndex, 1);
    writeMessages(messages);
    
    res.json({ success: true, message: 'Сообщение удалено' });
});

// Запуск сервера
app.listen(PORT, '0.0.0.0', () => {
    console.log(`
Сервер LinkUp запущен!
Локальный доступ: http://localhost:${PORT}
Доступ с телефона: http://[ВАШ IP]:${PORT}
-------------------------------------------
КОМАНДА ДЛЯ IP
Windows: введите 'ipconfig' в cmd
Mac/Linux: введите 'ifconfig'
    `);
});