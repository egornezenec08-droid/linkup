const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const multer = require('multer');  // ✅ правильно

const app = express();
const PORT = 3000;
const SALT_ROUNDS = 10;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..')));

// Настройка multer для загрузки файлов
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname);
        cb(null, uniqueName);
    }
});

const fileFilter = (req, file, cb) => {
    const allowedTypes = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'application/pdf', 'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain', 'application/zip', 'application/x-rar-compressed',
        'video/mp4', 'video/mpeg', 'audio/mpeg', 'audio/wav'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('Неподдерживаемый тип файла'));
    }
};

const upload = multer({
    storage: storage,
    limits: { fileSize: 50 * 1024 * 1024 }, // 50MB лимит
    fileFilter: fileFilter
});

// Пути к файлам
const usersFilePath = path.join(__dirname, 'users.json');
const messagesFilePath = path.join(__dirname, 'messages.json');

// Функции для работы с пользователями
function readUsers() {
    if (!fs.existsSync(usersFilePath)) {
        fs.writeFileSync(usersFilePath, JSON.stringify([]));
        return [];
    }
    const data = fs.readFileSync(usersFilePath, 'utf8');
    return JSON.parse(data);
}

function writeUsers(users) {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
}

function generateId(users) {
    if (users.length === 0) return 1;
    const maxId = Math.max(...users.map(user => user.ID));
    return maxId + 1;
}

// Функции для работы с сообщениями
function readMessages() {
    if (!fs.existsSync(messagesFilePath)) {
        fs.writeFileSync(messagesFilePath, JSON.stringify([]));
        return [];
    }
    const data = fs.readFileSync(messagesFilePath, 'utf8');
    return JSON.parse(data);
}

function writeMessages(messages) {
    fs.writeFileSync(messagesFilePath, JSON.stringify(messages, null, 2));
}

function generateMessageId(messages) {
    if (messages.length === 0) return 1;
    const maxId = Math.max(...messages.map(m => m.id));
    return maxId + 1;
}

// API: Загрузка файлов
app.post('/api/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, message: 'Файл не загружен' });
    }
    
    const fileUrl = `/uploads/${req.file.filename}`;
    const fileType = req.file.mimetype.startsWith('image/') ? 'image' : 'file';
    
    res.json({
        success: true,
        fileUrl: fileUrl,
        fileName: req.file.originalname,
        fileSize: req.file.size,
        fileType: fileType,
        mimeType: req.file.mimetype
    });
});

// Статическая раздача загруженных файлов
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// API: Регистрация
app.post('/api/register', async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Заполните все поля' });
    }
    
    const users = readUsers();
    
    const userExists = users.some(user => user.username === username);
    if (userExists) {
        return res.status(400).json({ success: false, message: 'Пользователь уже существует' });
    }
    
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
    
    const newUser = {
        username: username,
        password: hashedPassword,
        ID: generateId(users)
    };
    
    users.push(newUser);
    writeUsers(users);
    
    console.log(`✅ Новый пользователь: ${username} (ID: ${newUser.ID})`);
    res.json({ success: true, message: 'Регистрация успешна', user: { username, ID: newUser.ID } });
});

// API: Авторизация
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Заполните все поля' });
    }
    
    const users = readUsers();
    const user = users.find(user => user.username === username);
    
    if (user && await bcrypt.compare(password, user.password)) {
        console.log(`🔓 Авторизация: ${username} (ID: ${user.ID})`);
        res.json({ success: true, message: 'Вход выполнен', user: { username, ID: user.ID } });
    } else {
        res.status(401).json({ success: false, message: 'Неверный логин или пароль' });
    }
});

// API: Получить всех пользователей
app.get('/api/users', (req, res) => {
    const users = readUsers();
    const safeUsers = users.map(({ password, ...user }) => user);
    res.json(safeUsers);
});

// API: Поиск пользователей
app.get('/api/users/search', (req, res) => {
    const { query } = req.query;
    const currentUsername = req.headers['x-current-user'];
    
    if (!query || query.trim() === '') {
        return res.json([]);
    }
    
    const users = readUsers();
    
    const results = users
        .filter(user => 
            user.username.toLowerCase().includes(query.toLowerCase()) &&
            user.username !== currentUsername
        )
        .map(({ username, ID }) => ({ username, ID }));
    
    res.json(results);
});

// API: Получить список чатов
app.get('/api/chats/:userId', (req, res) => {
    const { userId } = req.params;
    const messages = readMessages();
    
    const chatPartners = new Set();
    
    messages.forEach(msg => {
        if (msg.fromId == userId) {
            chatPartners.add(msg.toId);
        } else if (msg.toId == userId) {
            chatPartners.add(msg.fromId);
        }
    });
    
    const users = readUsers();
    const chats = Array.from(chatPartners).map(partnerId => {
        const user = users.find(u => u.ID == partnerId);
        if (!user) return null;
        
        const userMessages = messages.filter(m => 
            (m.fromId == userId && m.toId == partnerId) ||
            (m.fromId == partnerId && m.toId == userId)
        );
        
        const lastMessage = userMessages.sort((a,b) => b.timestamp - a.timestamp)[0];
        
        let lastMessageText = '';
        if (lastMessage) {
            if (lastMessage.isFile) {
                lastMessageText = `📎 ${lastMessage.fileName}`;
            } else {
                lastMessageText = lastMessage.text;
            }
        }
        
        return {
            userId: partnerId,
            username: user.username,
            lastMessage: lastMessageText,
            lastMessageTime: lastMessage ? lastMessage.timestamp : null
        };
    }).filter(chat => chat !== null);
    
    res.json(chats);
});

// API: Получить сообщения между пользователями
app.get('/api/messages/:userId1/:userId2', (req, res) => {
    const { userId1, userId2 } = req.params;
    const messages = readMessages();
    
    const chatMessages = messages.filter(m => 
        (m.fromId == userId1 && m.toId == userId2) ||
        (m.fromId == userId2 && m.toId == userId1)
    ).sort((a,b) => a.timestamp - b.timestamp);
    
    res.json(chatMessages);
});

// API: Отправить текстовое сообщение
app.post('/api/messages', (req, res) => {
    const { fromId, toId, text } = req.body;
    
    if (!fromId || !toId || !text) {
        return res.status(400).json({ success: false, message: 'Недостаточно данных' });
    }
    
    const messages = readMessages();
    
    const newMessage = {
        id: generateMessageId(messages),
        fromId: parseInt(fromId),
        toId: parseInt(toId),
        text: text,
        timestamp: Date.now(),
        read: false,
        isFile: false
    };
    
    messages.push(newMessage);
    writeMessages(messages);
    
    console.log(`💬 Сообщение: ${newMessage.fromId} -> ${newMessage.toId}: ${text.substring(0, 30)}`);
    res.json({ success: true, message: newMessage });
});

// API: Отправить файл
app.post('/api/messages/file', upload.single('file'), (req, res) => {
    const { fromId, toId } = req.body;
    
    if (!fromId || !toId || !req.file) {
        return res.status(400).json({ success: false, message: 'Недостаточно данных' });
    }
    
    const messages = readMessages();
    const fileUrl = `/uploads/${req.file.filename}`;
    const isImage = req.file.mimetype.startsWith('image/');
    
    const newMessage = {
        id: generateMessageId(messages),
        fromId: parseInt(fromId),
        toId: parseInt(toId),
        text: isImage ? '' : req.file.originalname,
        timestamp: Date.now(),
        read: false,
        isFile: true,
        fileUrl: fileUrl,
        fileName: req.file.originalname,
        fileSize: req.file.size,
        fileType: req.file.mimetype,
        isImage: isImage
    };
    
    messages.push(newMessage);
    writeMessages(messages);
    
    console.log(`📎 Файл: ${newMessage.fromId} -> ${newMessage.toId}: ${req.file.originalname}`);
    res.json({ success: true, message: newMessage });
});

// API: Удалить сообщение
app.delete('/api/messages/:messageId/:userId', (req, res) => {
    const { messageId, userId } = req.params;
    let messages = readMessages();
    
    const messageIndex = messages.findIndex(m => m.id == messageId);
    
    if (messageIndex === -1) {
        return res.status(404).json({ success: false, message: 'Сообщение не найдено' });
    }
    
    if (messages[messageIndex].fromId != userId) {
        return res.status(403).json({ success: false, message: 'Можно удалять только свои сообщения' });
    }
    
    // Удаляем файл с диска если это было файловое сообщение
    if (messages[messageIndex].isFile && messages[messageIndex].fileUrl) {
        const filePath = path.join(__dirname, messages[messageIndex].fileUrl);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }
    
    messages.splice(messageIndex, 1);
    writeMessages(messages);
    
    res.json({ success: true, message: 'Сообщение удалено' });
});

// Запуск сервера
app.listen(PORT, '0.0.0.0', () => {
    console.log(`
Сервер LinkUp запущен!
Локальный доступ: http://localhost:${PORT}
Доступ с телефона: http://[ВАШ IP]:${PORT}
-------------------------------------------
Поддерживаются файлы: изображения, документы, видео, аудио, архивы
Максимальный размер: 50MB
    `);
});