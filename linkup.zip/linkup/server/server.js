const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..'))); // Раздаём файлы из родительской папки

// Путь к файлу с пользователями
const usersFilePath = path.join(__dirname, 'users.json');

// Функция для чтения пользователей из файла
function readUsers() {
    if (!fs.existsSync(usersFilePath)) {
        fs.writeFileSync(usersFilePath, JSON.stringify([]));
        return [];
    }
    const data = fs.readFileSync(usersFilePath, 'utf8');
    return JSON.parse(data);
}

// Функция для записи пользователей в файл
function writeUsers(users) {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
}

// Функция для генерации уникального ID
function generateId(users) {
    if (users.length === 0) return 1;
    const maxId = Math.max(...users.map(user => user.ID));
    return maxId + 1;
}

// API: Регистрация
app.post('/api/register', (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Заполните все поля' });
    }
    
    const users = readUsers();
    
    // Проверяем, существует ли пользователь
    const userExists = users.some(user => user.username === username);
    if (userExists) {
        return res.status(400).json({ success: false, message: 'Пользователь уже существует' });
    }
    
    // Создаём нового пользователя
    const newUser = {
        username: username,
        password: password,
        ID: generateId(users)
    };
    
    users.push(newUser);
    writeUsers(users);
    
    console.log(`✅ Новый пользователь: ${username} (ID: ${newUser.ID})`);
    res.json({ success: true, message: 'Регистрация успешна', user: { username, ID: newUser.ID } });
});

// API: Авторизация
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ success: false, message: 'Заполните все поля' });
    }
    
    const users = readUsers();
    const user = users.find(user => user.username === username && user.password === password);
    
    if (user) {
        console.log(`🔓 Авторизация: ${username} (ID: ${user.ID})`);
        res.json({ success: true, message: 'Вход выполнен', user: { username, ID: user.ID } });
    } else {
        res.status(401).json({ success: false, message: 'Неверный логин или пароль' });
    }
});

// API: Получить всех пользователей (для отладки)
app.get('/api/users', (req, res) => {
    const users = readUsers();
    res.json(users);
});

// Запуск сервера
app.listen(PORT, '0.0.0.0', () => {
    console.log(`
Сервер LinkUp запущен!
Локальный доступ: http://localhost:${PORT}
Доступ с телефона: http://[ВАШ IP]:${PORT}
-------------------------------------------
КОМАНДА ДЛЯ IP
Windows: введите 'ipconfig' в cmd
Mac/Linux: введите 'ifconfig'
    `);
});